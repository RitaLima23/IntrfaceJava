package modeloDao;

import modeloConection.ConexaoBD;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import modeloBeans.BeansFornecedores;
  

public class DaoFornecedores {
    
    ConexaoBD conex = new ConexaoBD();
    BeansFornecedores mod = new BeansFornecedores();
    
    public void Salvar(BeansFornecedores mod){
        conex.conexao();
        try {
            PreparedStatement pst = conex.con.prepareStatement("insert into fornecedores(Nome_Fornecedor,Cnpj_Fornecedor,Endereco_Fornecedor,Telefone_Fornecedor,ramificacao_Fornecedor)values(?,?,?,?,?)");
            pst.setString(1,mod.getNome());
            pst.setString(2,mod.getCnpj());
            pst.setString(3,mod.getEndereco());
            pst.setString(4,mod.getTelefone());
            pst.setString(5,mod.getRamificacao());
            pst.execute();
            JOptionPane.showMessageDialog(null,"Dados Inseridos Com Sucesso!");
                 
        } catch (SQLException ex) {
           JOptionPane.showMessageDialog(null,"Erro ao inserir Dados!/nErro:"+ex);
        }
        
        conex.desconecta();
    }
    
    public BeansFornecedores buscaFornecedores(BeansFornecedores mod){
         conex.conexao();
         conex.executasql("select *from fornecedores where Nome_Fornecedor like '% "+mod.getPesquisa()+"%'");
         try {
         conex.rs.first();
         mod.setCodigo(conex.rs.getInt("Cod_Fornecedor"));
         mod.setNome(conex.rs.getString("Nome_Fornecedor"));
         mod.setCnpj(conex.rs.getString("Cnpj_Fornecedor"));
         mod.setEndereco(conex.rs.getString("Endereco_Fornecedor"));
         mod.setTelefone(conex.rs.getString("Telefone_Fornecedor"));
         mod.setRamificacao(conex.rs.getString("ramificacao_Fornecedor"));
         }catch (SQLException ex){
             JOptionPane.showMessageDialog(null,"Erro ao buscar Fornecedor Cadastrado!"+ex);
         }
        conex.desconecta();
        return mod;
    }
    
    
    
    
}
