/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author cassi
 */
@Entity
@Table(name = "fornecedores", catalog = "projetoredes", schema = "")
@NamedQueries({
    @NamedQuery(name = "Fornecedores.findAll", query = "SELECT f FROM Fornecedores f")
    , @NamedQuery(name = "Fornecedores.findByCodFornecedor", query = "SELECT f FROM Fornecedores f WHERE f.codFornecedor = :codFornecedor")
    , @NamedQuery(name = "Fornecedores.findByNomeFornecedor", query = "SELECT f FROM Fornecedores f WHERE f.nomeFornecedor = :nomeFornecedor")
    , @NamedQuery(name = "Fornecedores.findByCnpjFornecedor", query = "SELECT f FROM Fornecedores f WHERE f.cnpjFornecedor = :cnpjFornecedor")
    , @NamedQuery(name = "Fornecedores.findByEnderecoFornecedor", query = "SELECT f FROM Fornecedores f WHERE f.enderecoFornecedor = :enderecoFornecedor")
    , @NamedQuery(name = "Fornecedores.findByTelefoneFornecedor", query = "SELECT f FROM Fornecedores f WHERE f.telefoneFornecedor = :telefoneFornecedor")
    , @NamedQuery(name = "Fornecedores.findByRamificacaoFornecedor", query = "SELECT f FROM Fornecedores f WHERE f.ramificacaoFornecedor = :ramificacaoFornecedor")})
public class Fornecedores implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "Cod_Fornecedor")
    private Integer codFornecedor;
    @Column(name = "Nome_Fornecedor")
    private String nomeFornecedor;
    @Column(name = "Cnpj_Fornecedor")
    private String cnpjFornecedor;
    @Column(name = "Endereco_Fornecedor")
    private String enderecoFornecedor;
    @Column(name = "Telefone_Fornecedor")
    private String telefoneFornecedor;
    @Column(name = "ramificacao_Fornecedor")
    private String ramificacaoFornecedor;

    public Fornecedores() {
    }

    public Fornecedores(Integer codFornecedor) {
        this.codFornecedor = codFornecedor;
    }

    public Integer getCodFornecedor() {
        return codFornecedor;
    }

    public void setCodFornecedor(Integer codFornecedor) {
        Integer oldCodFornecedor = this.codFornecedor;
        this.codFornecedor = codFornecedor;
        changeSupport.firePropertyChange("codFornecedor", oldCodFornecedor, codFornecedor);
    }

    public String getNomeFornecedor() {
        return nomeFornecedor;
    }

    public void setNomeFornecedor(String nomeFornecedor) {
        String oldNomeFornecedor = this.nomeFornecedor;
        this.nomeFornecedor = nomeFornecedor;
        changeSupport.firePropertyChange("nomeFornecedor", oldNomeFornecedor, nomeFornecedor);
    }

    public String getCnpjFornecedor() {
        return cnpjFornecedor;
    }

    public void setCnpjFornecedor(String cnpjFornecedor) {
        String oldCnpjFornecedor = this.cnpjFornecedor;
        this.cnpjFornecedor = cnpjFornecedor;
        changeSupport.firePropertyChange("cnpjFornecedor", oldCnpjFornecedor, cnpjFornecedor);
    }

    public String getEnderecoFornecedor() {
        return enderecoFornecedor;
    }

    public void setEnderecoFornecedor(String enderecoFornecedor) {
        String oldEnderecoFornecedor = this.enderecoFornecedor;
        this.enderecoFornecedor = enderecoFornecedor;
        changeSupport.firePropertyChange("enderecoFornecedor", oldEnderecoFornecedor, enderecoFornecedor);
    }

    public String getTelefoneFornecedor() {
        return telefoneFornecedor;
    }

    public void setTelefoneFornecedor(String telefoneFornecedor) {
        String oldTelefoneFornecedor = this.telefoneFornecedor;
        this.telefoneFornecedor = telefoneFornecedor;
        changeSupport.firePropertyChange("telefoneFornecedor", oldTelefoneFornecedor, telefoneFornecedor);
    }

    public String getRamificacaoFornecedor() {
        return ramificacaoFornecedor;
    }

    public void setRamificacaoFornecedor(String ramificacaoFornecedor) {
        String oldRamificacaoFornecedor = this.ramificacaoFornecedor;
        this.ramificacaoFornecedor = ramificacaoFornecedor;
        changeSupport.firePropertyChange("ramificacaoFornecedor", oldRamificacaoFornecedor, ramificacaoFornecedor);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (codFornecedor != null ? codFornecedor.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Fornecedores)) {
            return false;
        }
        Fornecedores other = (Fornecedores) object;
        if ((this.codFornecedor == null && other.codFornecedor != null) || (this.codFornecedor != null && !this.codFornecedor.equals(other.codFornecedor))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "view.Fornecedores[ codFornecedor=" + codFornecedor + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
