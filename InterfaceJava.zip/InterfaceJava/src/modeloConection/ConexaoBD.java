
package modeloConection;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;



public class ConexaoBD { 

    
   public Statement stm; //Realiza a pesquisa no BD
   public ResultSet rs; // Armazena o resultado da pesquisa;
   private String driver = "com.mysql.jdbc.Driver"; // Identifica o serviço do BD;
   private String caminho = "jdbc:mysql://localhost:3306/projetoredes"; // Onde está alocado o BD;
   private String usuario = "root"; // USER do bd;
   private String senha = "euamojesus18"; // SENHA do bd;
   public Connection con;
    
    
       public void conexao(){
           
        try {
        System.setProperty("jdbc.Driver", driver);
        con=DriverManager.getConnection(caminho,usuario,senha);
           // JOptionPane.showMessageDialog(null, "Conexao Efetuada com Sucesso!");
        } catch (SQLException ex){
           JOptionPane.showMessageDialog(null,"Erro ao se conectar ao Banco de dados:"+ ex);
  
        }
    }
       
       public void executasql(String sql){
       try {
           stm = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE,rs.CONCUR_READ_ONLY);
           rs = stm.executeQuery(sql);
       } catch (SQLException ex) {
           JOptionPane.showMessageDialog(null,"Erro executasql:"+ ex.getMessage());
       }
       }
       
       
       
       public static void main(String[]args){
        ConexaoBD conecta = new ConexaoBD();
        conecta.conexao();
   }
       
    public void desconecta(){
        try{
            con.close();
            //JOptionPane.showMessageDialog(null, "BD Desconectado com sucesso!");
        }catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Erro ao fechar conexão com Banco de dados.\n"+ex.getMessage());
            
        }
    }
}


